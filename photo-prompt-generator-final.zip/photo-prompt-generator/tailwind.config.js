/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './pages/**/*.{js,ts,jsx,tsx,mdx}',
    './components/**/*.{js,ts,jsx,tsx,mdx}',
    './app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      fontFamily: {
        display: ['var(--font-display)', 'serif'],
        body: ['var(--font-body)', 'sans-serif'],
        mono: ['var(--font-mono)', 'monospace'],
      },
      colors: {
        obsidian: {
          950: '#080810',
          900: '#0d0d1a',
          800: '#12121f',
          700: '#1a1a2e',
          600: '#22223d',
        },
        gold: {
          300: '#f0d080',
          400: '#e8c060',
          500: '#d4a832',
          600: '#b8901e',
        },
        silver: {
          100: '#f0f0f5',
          200: '#dcdce8',
          300: '#b8b8cc',
          400: '#9090a8',
          500: '#6868848',
        }
      },
      animation: {
        'fade-in': 'fadeIn 0.6s ease forwards',
        'slide-up': 'slideUp 0.5s ease forwards',
        'shimmer': 'shimmer 2s infinite',
        'pulse-gold': 'pulseGold 2s ease-in-out infinite',
        'scan': 'scan 3s ease-in-out infinite',
      },
      keyframes: {
        fadeIn: {
          from: { opacity: '0' },
          to: { opacity: '1' },
        },
        slideUp: {
          from: { opacity: '0', transform: 'translateY(20px)' },
          to: { opacity: '1', transform: 'translateY(0)' },
        },
        shimmer: {
          '0%': { backgroundPosition: '-200% center' },
          '100%': { backgroundPosition: '200% center' },
        },
        pulseGold: {
          '0%, 100%': { boxShadow: '0 0 10px rgba(212, 168, 50, 0.3)' },
          '50%': { boxShadow: '0 0 30px rgba(212, 168, 50, 0.6), 0 0 60px rgba(212, 168, 50, 0.2)' },
        },
        scan: {
          '0%': { top: '0%', opacity: '1' },
          '50%': { top: '100%', opacity: '0.5' },
          '100%': { top: '0%', opacity: '1' },
        }
      },
    },
  },
  plugins: [],
}
