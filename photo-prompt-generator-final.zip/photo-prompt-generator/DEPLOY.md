# 🚀 GUIA DE DEPLOY — 3 ETAPAS SIMPLES

> Você NÃO precisa instalar nada no seu computador.
> O Vercel faz tudo automaticamente.

---

## ETAPA 1 — Subir para o GitHub

### 1.1 Crie uma conta
Acesse → https://github.com e crie uma conta gratuita.

### 1.2 Crie um repositório novo
- Clique no botão verde **"New"** (canto superior esquerdo)
- **Repository name:** `photo-prompt-generator`
- Deixe como **Public**
- Clique em **"Create repository"**

### 1.3 Faça upload dos arquivos
Na página do repositório recém criado:
- Clique em **"uploading an existing file"**
- Arraste a pasta inteira do projeto (ou selecione todos os arquivos)
- IMPORTANTE: mantenha a estrutura de pastas:
  ```
  app/
    api/generate-prompts/route.ts
    globals.css
    layout.tsx
    page.tsx
  components/
    ImageUpload.tsx
    PromptCard.tsx
  .env.example
  next.config.js
  package.json
  postcss.config.js
  tailwind.config.js
  tsconfig.json
  ```
- Clique em **"Commit changes"** (botão verde lá embaixo)

✅ Seu código está no GitHub!

---

## ETAPA 2 — Pegar a Chave da Anthropic

### 2.1 Crie uma conta
Acesse → https://console.anthropic.com e crie uma conta.

### 2.2 Adicione créditos (obrigatório)
- Vá em **"Billing"** → **"Add credit"**
- Adicione o mínimo ($5 dólares)
- Sem créditos a API não funciona

### 2.3 Gere a chave
- Vá em **"Settings"** → **"API Keys"**
- Clique em **"Create Key"**
- Dê um nome (ex: "meu-gerador")
- **Copie a chave** — começa com `sk-ant-api03-...`
- ⚠️ Guarde em lugar seguro, ela aparece só uma vez!

---

## ETAPA 3 — Deploy no Vercel

### 3.1 Crie uma conta
Acesse → https://vercel.com e clique em **"Sign Up"**
- Use a opção **"Continue with GitHub"** (mais fácil!)

### 3.2 Importe o projeto
- No painel, clique em **"Add New..."** → **"Project"**
- Você verá seus repositórios do GitHub listados
- Clique em **"Import"** no repositório `photo-prompt-generator`

### 3.3 Configure a variável de ambiente
Na tela de configuração, ANTES de clicar em Deploy:
- Abra a seção **"Environment Variables"**
- Preencha:
  - **Name:** `ANTHROPIC_API_KEY`
  - **Value:** `sk-ant-api03-...` (cole sua chave aqui)
- Clique em **"Add"**

### 3.4 Deploy!
- Clique no botão **"Deploy"**
- Aguarde ~2 minutos
- 🎉 Seu site está no ar!

A URL será algo como:
`https://photo-prompt-generator-abc123.vercel.app`

---

## ✅ RESUMO VISUAL

```
GitHub                    Anthropic               Vercel
──────                    ─────────               ──────
1. Criar conta            1. Criar conta          1. Criar conta
2. Novo repositório       2. Adicionar $5         2. Importar do GitHub
3. Upload dos arquivos    3. Copiar chave API     3. Colar chave API
                                                  4. Clicar Deploy ✅
```

---

## ❓ Problemas Comuns

**"Build failed" no Vercel**
→ Verifique se fez upload de TODOS os arquivos, incluindo os dentro das pastas `app/` e `components/`

**"API error" ao gerar prompts**
→ Verifique se colou a chave correta em Environment Variables
→ Verifique se adicionou créditos na Anthropic

**Página em branco**
→ Abra o painel do Vercel → seu projeto → aba "Functions" para ver os logs de erro

---

*Qualquer dúvida, print o erro e pergunte!*
