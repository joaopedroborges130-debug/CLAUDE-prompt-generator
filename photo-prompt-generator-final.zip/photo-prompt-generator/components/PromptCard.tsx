'use client'

import { useState } from 'react'

interface PromptCardProps {
  id: number
  titulo: string
  descricao: string
  prompt: string
  delay?: number
}

const PROMPT_ICONS = ['◉', '◈', '◎', '⬡', '✦']
const PROMPT_LABELS = [
  'PROMPT 01',
  'PROMPT 02',
  'PROMPT 03',
  'PROMPT 04',
  'PROMPT 05',
]

export default function PromptCard({ id, titulo, descricao, prompt, delay = 0 }: PromptCardProps) {
  const [copied, setCopied] = useState(false)

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(prompt)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    } catch {
      // Fallback for older browsers
      const textarea = document.createElement('textarea')
      textarea.value = prompt
      document.body.appendChild(textarea)
      textarea.select()
      document.execCommand('copy')
      document.body.removeChild(textarea)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const icon = PROMPT_ICONS[(id - 1) % PROMPT_ICONS.length]
  const label = PROMPT_LABELS[(id - 1) % PROMPT_LABELS.length]

  return (
    <div
      className="prompt-card rounded-xl p-5 prompt-card-enter"
      style={{ animationDelay: `${delay}ms`, animationFillMode: 'both' }}
    >
      {/* Header */}
      <div className="flex items-start justify-between mb-4 gap-3">
        <div className="flex items-center gap-3 flex-1 min-w-0">
          {/* Number badge */}
          <div className="number-badge rounded-md px-2 py-1 flex-shrink-0 flex items-center gap-1.5">
            <span style={{ color: 'var(--gold-400)' }}>{icon}</span>
            <span>{label}</span>
          </div>

          {/* Title & description */}
          <div className="min-w-0">
            <h3
              className="font-display font-semibold text-sm truncate"
              style={{ color: 'var(--text-primary)' }}
            >
              {titulo}
            </h3>
            <p
              className="text-xs mt-0.5 truncate"
              style={{ color: 'var(--text-secondary)' }}
            >
              {descricao}
            </p>
          </div>
        </div>

        {/* Copy button */}
        <button
          onClick={handleCopy}
          className="copy-btn rounded-lg px-3 py-1.5 flex items-center gap-1.5 flex-shrink-0"
          style={{
            background: copied ? 'rgba(212, 168, 50, 0.15)' : 'rgba(255,255,255,0.04)',
            border: '1px solid',
            borderColor: copied ? 'rgba(212, 168, 50, 0.4)' : 'rgba(255,255,255,0.08)',
            color: copied ? 'var(--gold-400)' : 'var(--text-secondary)',
            fontSize: '0.75rem',
            fontFamily: 'var(--font-mono)',
          }}
        >
          {copied ? (
            <>
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                <polyline points="20,6 9,17 4,12"></polyline>
              </svg>
              Copiado!
            </>
          ) : (
            <>
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
                <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
              </svg>
              Copiar
            </>
          )}
        </button>
      </div>

      {/* Divider */}
      <div className="deco-line mb-4" />

      {/* Prompt text */}
      <p
        className="text-sm leading-relaxed"
        style={{
          color: 'var(--text-primary)',
          fontFamily: 'var(--font-body)',
          lineHeight: '1.7',
        }}
      >
        {prompt}
      </p>

      {/* Character count */}
      <div
        className="mt-3 text-right"
        style={{
          color: 'var(--text-secondary)',
          fontSize: '0.65rem',
          fontFamily: 'var(--font-mono)',
        }}
      >
        {prompt.length} caracteres
      </div>
    </div>
  )
}
