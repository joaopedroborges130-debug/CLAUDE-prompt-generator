'use client'

import { useRef, useState, useCallback } from 'react'

interface ImageUploadProps {
  onImageSelect: (file: File, preview: string) => void
  preview: string | null
  isLoading: boolean
}

export default function ImageUpload({ onImageSelect, preview, isLoading }: ImageUploadProps) {
  const inputRef = useRef<HTMLInputElement>(null)
  const [isDragging, setIsDragging] = useState(false)

  const handleFile = useCallback((file: File) => {
    if (!file.type.startsWith('image/')) return
    const reader = new FileReader()
    reader.onloadend = () => {
      onImageSelect(file, reader.result as string)
    }
    reader.readAsDataURL(file)
  }, [onImageSelect])

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(false)
    const file = e.dataTransfer.files[0]
    if (file) handleFile(file)
  }, [handleFile])

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(true)
  }

  const handleDragLeave = () => setIsDragging(false)

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) handleFile(file)
  }

  return (
    <div className="w-full">
      <input
        ref={inputRef}
        type="file"
        accept="image/*"
        onChange={handleChange}
        className="hidden"
        id="image-upload"
      />

      {preview ? (
        /* Preview State */
        <div className="relative rounded-xl overflow-hidden" style={{ background: 'var(--bg-card)' }}>
          <div className="relative">
            <img
              src={preview}
              alt="Imagem de referência"
              className="w-full object-contain max-h-96 rounded-xl"
              style={{ display: 'block' }}
            />

            {/* Scanning overlay when loading */}
            {isLoading && (
              <div className="absolute inset-0 rounded-xl" style={{ background: 'rgba(8,8,16,0.6)' }}>
                <div className="scan-line" />
                <div className="absolute inset-0 flex flex-col items-center justify-center gap-3">
                  <div className="flex gap-2">
                    <div
                      className="w-2 h-2 rounded-full loading-dot"
                      style={{ background: 'var(--gold-400)' }}
                    />
                    <div
                      className="w-2 h-2 rounded-full loading-dot"
                      style={{ background: 'var(--gold-400)' }}
                    />
                    <div
                      className="w-2 h-2 rounded-full loading-dot"
                      style={{ background: 'var(--gold-400)' }}
                    />
                  </div>
                  <p
                    style={{
                      color: 'var(--gold-400)',
                      fontFamily: 'var(--font-mono)',
                      fontSize: '0.7rem',
                      letterSpacing: '0.15em',
                    }}
                  >
                    ANALISANDO IMAGEM...
                  </p>
                </div>
              </div>
            )}

            {/* Change photo button */}
            {!isLoading && (
              <button
                onClick={() => inputRef.current?.click()}
                className="absolute bottom-3 right-3 rounded-lg px-3 py-1.5 flex items-center gap-1.5"
                style={{
                  background: 'rgba(8,8,16,0.85)',
                  border: '1px solid rgba(255,255,255,0.1)',
                  color: 'var(--text-secondary)',
                  fontSize: '0.75rem',
                  fontFamily: 'var(--font-mono)',
                  backdropFilter: 'blur(8px)',
                  transition: 'all 0.2s ease',
                }}
                onMouseEnter={e => {
                  (e.target as HTMLButtonElement).style.color = 'var(--gold-400)'
                  ;(e.target as HTMLButtonElement).style.borderColor = 'rgba(212,168,50,0.3)'
                }}
                onMouseLeave={e => {
                  (e.target as HTMLButtonElement).style.color = 'var(--text-secondary)'
                  ;(e.target as HTMLButtonElement).style.borderColor = 'rgba(255,255,255,0.1)'
                }}
              >
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
                  <polyline points="17,8 12,3 7,8"></polyline>
                  <line x1="12" y1="3" x2="12" y2="15"></line>
                </svg>
                Trocar foto
              </button>
            )}
          </div>
        </div>
      ) : (
        /* Upload State */
        <label
          htmlFor="image-upload"
          className={`upload-zone rounded-xl cursor-pointer flex flex-col items-center justify-center gap-4 py-16 px-8 ${isDragging ? 'dragging' : ''}`}
          onDrop={handleDrop}
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          style={{ minHeight: '220px' }}
        >
          {/* Upload icon */}
          <div
            className="w-16 h-16 rounded-full flex items-center justify-center"
            style={{
              background: 'rgba(212, 168, 50, 0.08)',
              border: '1px solid rgba(212, 168, 50, 0.2)',
            }}
          >
            <svg
              width="28"
              height="28"
              viewBox="0 0 24 24"
              fill="none"
              stroke="var(--gold-500)"
              strokeWidth="1.5"
            >
              <rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect>
              <circle cx="8.5" cy="8.5" r="1.5"></circle>
              <polyline points="21,15 16,10 5,21"></polyline>
            </svg>
          </div>

          <div className="text-center">
            <p
              className="font-display text-base font-medium mb-1"
              style={{ color: 'var(--text-primary)' }}
            >
              Arraste uma foto ou clique para selecionar
            </p>
            <p
              className="text-sm"
              style={{ color: 'var(--text-secondary)' }}
            >
              JPG, PNG, WEBP — até 20MB
            </p>
          </div>

          <div
            className="px-4 py-1.5 rounded-full text-xs"
            style={{
              background: 'rgba(212, 168, 50, 0.1)',
              border: '1px solid rgba(212, 168, 50, 0.2)',
              color: 'var(--gold-400)',
              fontFamily: 'var(--font-mono)',
              letterSpacing: '0.1em',
            }}
          >
            SELECIONAR ARQUIVO
          </div>
        </label>
      )}
    </div>
  )
}
