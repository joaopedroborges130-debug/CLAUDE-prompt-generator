# 📸 Gerador de Prompts para Ensaio Fotográfico IA

Uma ferramenta web elegante que analisa fotos de referência e gera automaticamente **5 prompts detalhados em português** para recriar ou variar a cena com IA generativa.

![Next.js](https://img.shields.io/badge/Next.js-14-black?style=flat-square&logo=next.js)
![TypeScript](https://img.shields.io/badge/TypeScript-5-blue?style=flat-square&logo=typescript)
![Tailwind CSS](https://img.shields.io/badge/Tailwind-3-38bdf8?style=flat-square&logo=tailwindcss)
![Claude AI](https://img.shields.io/badge/Claude-Vision-orange?style=flat-square)

---

## ✨ Funcionalidades

- **Upload por clique ou drag-and-drop** de imagens (JPG, PNG, WEBP)
- **Análise automática** da imagem via Claude Vision (Anthropic)
- **5 prompts distintos** gerados em português:
  - 🎯 Fiel ao Original — descrição quase idêntica à foto
  - 📐 Variação de Ângulo — mesma cena, outro ângulo de câmera
  - 🧍 Variação de Pose — mesma cena, pose diferente
  - 💡 Variação de Iluminação — mudança de luz ou enquadramento
  - ✨ Variação Criativa — outro clique do mesmo ensaio
- **Botão de copiar** por prompt individual e "Copiar todos"
- **Animação de scanning** durante o processamento
- Interface dark luxury com tema dourado

---

## 🗂️ Estrutura do Projeto

```
photo-prompt-generator/
├── app/
│   ├── api/
│   │   └── generate-prompts/
│   │       └── route.ts          # API Route — chama Claude Vision
│   ├── globals.css               # Estilos globais + animações
│   ├── layout.tsx                # Layout raiz com Google Fonts
│   └── page.tsx                  # Página principal
├── components/
│   ├── ImageUpload.tsx           # Componente de upload / preview
│   └── PromptCard.tsx            # Card de cada prompt gerado
├── public/                       # Assets estáticos
├── .env.example                  # Exemplo de variáveis de ambiente
├── .gitignore
├── next.config.js
├── package.json
├── postcss.config.js
├── tailwind.config.js
└── tsconfig.json
```

---

## 🚀 Rodando Localmente

### Pré-requisitos

- **Node.js** 18+ instalado ([nodejs.org](https://nodejs.org))
- **npm** ou **yarn**
- Conta na [Anthropic](https://console.anthropic.com/) com créditos disponíveis

### Passo a Passo

**1. Clone ou baixe o projeto:**
```bash
git clone https://github.com/seu-usuario/photo-prompt-generator.git
cd photo-prompt-generator
```

**2. Instale as dependências:**
```bash
npm install
```

> Se aparecer erro de dependências, tente: `npm install --legacy-peer-deps`

**3. Instale o SDK da Anthropic:**
```bash
npm install @anthropic-ai/sdk
```

**4. Configure a variável de ambiente:**
```bash
cp .env.example .env.local
```

Abra o arquivo `.env.local` e adicione sua chave:
```env
ANTHROPIC_API_KEY=sk-ant-api03-xxxxxxxxxxxxxxxx
```

> 🔑 Obtenha sua chave em: [console.anthropic.com/settings/keys](https://console.anthropic.com/settings/keys)

**5. Inicie o servidor de desenvolvimento:**
```bash
npm run dev
```

**6. Acesse no navegador:**
```
http://localhost:3000
```

---

## ☁️ Deploy no Vercel

### Método 1 — Vercel CLI (recomendado)

**1. Instale a CLI do Vercel:**
```bash
npm install -g vercel
```

**2. Faça login:**
```bash
vercel login
```

**3. Deploy:**
```bash
vercel
```

Siga as perguntas interativas (aceite os padrões). O Vercel detecta Next.js automaticamente.

**4. Adicione a variável de ambiente no painel:**
- Acesse [vercel.com/dashboard](https://vercel.com/dashboard)
- Selecione seu projeto → **Settings** → **Environment Variables**
- Adicione:
  - **Name:** `ANTHROPIC_API_KEY`
  - **Value:** `sk-ant-api03-...`
  - **Environment:** Production, Preview, Development (marque todos)
- Clique em **Save**

**5. Faça redeploy para aplicar as variáveis:**
```bash
vercel --prod
```

---

### Método 2 — GitHub + Vercel (mais fácil para atualizações)

**1. Suba o projeto para o GitHub:**
```bash
git init
git add .
git commit -m "feat: initial commit"
git remote add origin https://github.com/seu-usuario/photo-prompt-generator.git
git push -u origin main
```

**2. Importe no Vercel:**
- Acesse [vercel.com/new](https://vercel.com/new)
- Clique em **Import Git Repository**
- Selecione o repositório
- Em **Environment Variables**, adicione `ANTHROPIC_API_KEY`
- Clique em **Deploy**

✅ A partir daí, cada `git push` faz deploy automático!

---

## 🔧 Variáveis de Ambiente

| Variável | Descrição | Obrigatória |
|----------|-----------|-------------|
| `ANTHROPIC_API_KEY` | Chave da API da Anthropic | ✅ Sim |

---

## 💡 Como Usar a Ferramenta

1. **Acesse** a URL da aplicação
2. **Faça upload** de uma foto de referência (arraste ou clique)
3. Clique em **"GERAR 5 PROMPTS"**
4. Aguarde a análise (2–15 segundos dependendo da imagem)
5. **Copie** os prompts individualmente ou clique em "Copiar todos"
6. Cole no gerador de imagens de sua preferência

---

## 🎨 Compatibilidade dos Prompts

Os prompts gerados são otimizados para:
- **Midjourney** (v5, v6)
- **DALL-E 3** (ChatGPT / API)
- **Stable Diffusion** (SDXL, SD 3)
- **Leonardo AI**
- **Adobe Firefly**
- **Ideogram**

---

## 🔮 Sugestões de Melhorias Futuras

### Funcionalidades
- [ ] **Histórico de gerações** — salvar prompts anteriores no localStorage
- [ ] **Seleção de estilo de prompt** — Midjourney, DALL-E, Stable Diffusion
- [ ] **Tradução automática** — gerar versão em inglês de cada prompt
- [ ] **Personalização dos prompts** — usuário ajusta elementos antes de gerar
- [ ] **Comparação visual** — mostrar imagem original ao lado das variações
- [ ] **Geração de imagem embutida** — integrar com Replicate ou fal.ai para gerar direto

### Técnicas
- [ ] **Rate limiting** — evitar abuso da API
- [ ] **Cache de análises** — reutilizar análise para variações adicionais
- [ ] **Upload múltiplo** — combinar elementos de várias fotos
- [ ] **Autenticação** — login para salvar histórico em nuvem
- [ ] **API pública** — expor endpoint para integrações externas
- [ ] **Batch generation** — gerar prompts para várias fotos de uma vez
- [ ] **Ajuste de temperatura** — controlar criatividade/fidelidade dos prompts
- [ ] **Tags de prompt** — destacar visualmente palavras-chave nos prompts

---

## ⚠️ Custos Estimados

O projeto usa o modelo `claude-opus-4-5` com visão. Estimativas aproximadas:

| Uso | Custo Estimado |
|-----|---------------|
| 1 geração (1 foto → 5 prompts) | ~$0.02–0.05 |
| 100 gerações/mês | ~$2–5 |
| 1.000 gerações/mês | ~$20–50 |

> Consulte a [página de preços da Anthropic](https://www.anthropic.com/pricing) para valores atualizados.

---

## 📄 Licença

MIT — use livremente para projetos pessoais e comerciais.

---

*Feito com ✦ e muito café*
