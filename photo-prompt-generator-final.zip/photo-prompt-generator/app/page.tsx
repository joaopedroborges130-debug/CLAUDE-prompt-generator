'use client'

import { useState } from 'react'
import ImageUpload from '@/components/ImageUpload'
import PromptCard from '@/components/PromptCard'

interface PromptData {
  id: number
  titulo: string
  descricao: string
  prompt: string
}

interface GeneratedPrompts {
  prompts: PromptData[]
}

export default function Home() {
  const [selectedFile, setSelectedFile] = useState<File | null>(null)
  const [imagePreview, setImagePreview] = useState<string | null>(null)
  const [prompts, setPrompts] = useState<PromptData[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const handleImageSelect = (file: File, preview: string) => {
    setSelectedFile(file)
    setImagePreview(preview)
    setPrompts([])
    setError(null)
  }

  const handleGenerate = async () => {
    if (!selectedFile) return

    setIsLoading(true)
    setError(null)
    setPrompts([])

    try {
      const formData = new FormData()
      formData.append('image', selectedFile)

      const response = await fetch('/api/generate-prompts', {
        method: 'POST',
        body: formData,
      })

      const data: GeneratedPrompts & { error?: string } = await response.json()

      if (!response.ok || data.error) {
        throw new Error(data.error || 'Erro ao gerar prompts.')
      }

      setPrompts(data.prompts)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Erro desconhecido. Tente novamente.')
    } finally {
      setIsLoading(false)
    }
  }

  const handleCopyAll = async () => {
    if (!prompts.length) return
    const allText = prompts
      .map((p) => `=== ${p.titulo.toUpperCase()} ===\n${p.prompt}`)
      .join('\n\n')
    await navigator.clipboard.writeText(allText)
  }

  return (
    <main
      className="min-h-screen py-12 px-4"
      style={{ background: 'var(--bg-primary)' }}
    >
      {/* Background decoration */}
      <div
        className="fixed inset-0 pointer-events-none"
        style={{
          background:
            'radial-gradient(ellipse 80% 50% at 50% -20%, rgba(212,168,50,0.06) 0%, transparent 60%)',
          zIndex: 0,
        }}
      />

      <div className="relative z-10 max-w-4xl mx-auto">

        {/* ── HEADER ── */}
        <header className="text-center mb-14">
          {/* Badge */}
          <div className="inline-flex items-center gap-2 rounded-full px-4 py-1.5 mb-6" style={{
            background: 'rgba(212, 168, 50, 0.08)',
            border: '1px solid rgba(212, 168, 50, 0.2)',
          }}>
            <span style={{ color: 'var(--gold-400)', fontSize: '0.6rem' }}>✦</span>
            <span style={{
              color: 'var(--gold-400)',
              fontSize: '0.65rem',
              fontFamily: 'var(--font-mono)',
              letterSpacing: '0.2em',
            }}>
              INTELIGÊNCIA ARTIFICIAL
            </span>
            <span style={{ color: 'var(--gold-400)', fontSize: '0.6rem' }}>✦</span>
          </div>

          {/* Title */}
          <h1
            className="font-display font-bold leading-tight mb-4"
            style={{ fontSize: 'clamp(1.8rem, 5vw, 3rem)' }}
          >
            <span className="text-shimmer">Gerador de Prompts</span>
            <br />
            <span style={{ color: 'var(--text-primary)' }}>para Ensaio Fotográfico</span>
          </h1>

          {/* Subtitle */}
          <p
            className="max-w-lg mx-auto text-base leading-relaxed"
            style={{ color: 'var(--text-secondary)' }}
          >
            Envie uma foto de referência e receba{' '}
            <span style={{ color: 'var(--gold-400)' }}>5 prompts detalhados</span>{' '}
            para recriar ou variar a cena com IA generativa.
          </p>
        </header>

        {/* ── UPLOAD SECTION ── */}
        <section
          className="rounded-2xl p-6 mb-6"
          style={{
            background: 'var(--bg-card)',
            border: '1px solid var(--border-subtle)',
          }}
        >
          <div className="flex items-center gap-2 mb-5">
            <div
              className="w-6 h-6 rounded flex items-center justify-center text-xs"
              style={{
                background: 'rgba(212,168,50,0.1)',
                border: '1px solid rgba(212,168,50,0.2)',
                color: 'var(--gold-400)',
                fontFamily: 'var(--font-mono)',
              }}
            >
              1
            </div>
            <span
              className="text-sm font-medium"
              style={{ color: 'var(--text-secondary)', fontFamily: 'var(--font-mono)', letterSpacing: '0.08em' }}
            >
              FOTO DE REFERÊNCIA
            </span>
          </div>

          <ImageUpload
            onImageSelect={handleImageSelect}
            preview={imagePreview}
            isLoading={isLoading}
          />
        </section>

        {/* ── GENERATE BUTTON ── */}
        <section className="mb-10">
          <button
            onClick={handleGenerate}
            disabled={!selectedFile || isLoading}
            className="btn-generate w-full py-4 rounded-xl text-sm flex items-center justify-center gap-3"
            style={{ letterSpacing: '0.1em' }}
          >
            {isLoading ? (
              <>
                <div className="flex gap-1.5">
                  <div className="w-1.5 h-1.5 rounded-full loading-dot" style={{ background: '#080810' }} />
                  <div className="w-1.5 h-1.5 rounded-full loading-dot" style={{ background: '#080810' }} />
                  <div className="w-1.5 h-1.5 rounded-full loading-dot" style={{ background: '#080810' }} />
                </div>
                <span>GERANDO PROMPTS...</span>
              </>
            ) : (
              <>
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <polygon points="13,2 3,14 12,14 11,22 21,10 12,10 13,2"></polygon>
                </svg>
                <span>GERAR 5 PROMPTS</span>
              </>
            )}
          </button>

          {/* Error */}
          {error && (
            <div
              className="mt-4 p-4 rounded-xl text-sm flex items-start gap-3"
              style={{
                background: 'rgba(220, 60, 60, 0.08)',
                border: '1px solid rgba(220, 60, 60, 0.25)',
                color: '#ff8080',
              }}
            >
              <svg
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                className="flex-shrink-0 mt-0.5"
              >
                <circle cx="12" cy="12" r="10"></circle>
                <line x1="12" y1="8" x2="12" y2="12"></line>
                <line x1="12" y1="16" x2="12.01" y2="16"></line>
              </svg>
              {error}
            </div>
          )}
        </section>

        {/* ── PROMPTS ── */}
        {prompts.length > 0 && (
          <section>
            {/* Section header */}
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <div
                  className="w-6 h-6 rounded flex items-center justify-center text-xs"
                  style={{
                    background: 'rgba(212,168,50,0.1)',
                    border: '1px solid rgba(212,168,50,0.2)',
                    color: 'var(--gold-400)',
                    fontFamily: 'var(--font-mono)',
                  }}
                >
                  2
                </div>
                <span
                  className="text-sm font-medium"
                  style={{ color: 'var(--text-secondary)', fontFamily: 'var(--font-mono)', letterSpacing: '0.08em' }}
                >
                  PROMPTS GERADOS — {prompts.length}/5
                </span>
              </div>

              {/* Copy all button */}
              <button
                onClick={handleCopyAll}
                className="copy-btn rounded-lg px-3 py-1.5 flex items-center gap-1.5 text-xs"
                style={{
                  background: 'rgba(255,255,255,0.04)',
                  border: '1px solid rgba(255,255,255,0.08)',
                  color: 'var(--text-secondary)',
                  fontFamily: 'var(--font-mono)',
                }}
              >
                <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
                  <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
                </svg>
                Copiar todos
              </button>
            </div>

            {/* Decorative line */}
            <div className="deco-line mb-6" />

            {/* Prompt cards */}
            <div className="flex flex-col gap-4">
              {prompts.map((prompt, index) => (
                <PromptCard
                  key={prompt.id}
                  {...prompt}
                  delay={index * 120}
                />
              ))}
            </div>

            {/* Footer note */}
            <div
              className="mt-8 text-center text-xs"
              style={{
                color: 'var(--text-secondary)',
                fontFamily: 'var(--font-mono)',
                letterSpacing: '0.05em',
              }}
            >
              ✦ Prompts otimizados para Midjourney, DALL-E 3, Stable Diffusion e Leonardo AI ✦
            </div>
          </section>
        )}

        {/* ── FOOTER ── */}
        <footer className="mt-16 text-center" style={{ color: 'var(--text-secondary)', fontSize: '0.7rem', fontFamily: 'var(--font-mono)', letterSpacing: '0.1em' }}>
          <div className="deco-line mb-6" />
          POWERED BY CLAUDE VISION · ANTHROPIC
        </footer>
      </div>
    </main>
  )
}
