import type { Metadata } from 'next'
import { Playfair_Display, DM_Sans, DM_Mono } from 'next/font/google'
import './globals.css'

const playfair = Playfair_Display({
  subsets: ['latin'],
  variable: '--font-display',
  display: 'swap',
})

const dmSans = DM_Sans({
  subsets: ['latin'],
  variable: '--font-body',
  display: 'swap',
})

const dmMono = DM_Mono({
  subsets: ['latin'],
  weight: ['300', '400', '500'],
  variable: '--font-mono',
  display: 'swap',
})

export const metadata: Metadata = {
  title: 'Gerador de Prompts para Ensaio Fotográfico IA',
  description: 'Transforme fotos de referência em prompts detalhados para geração de imagens hiper-realistas com IA',
  keywords: 'prompts fotografia, IA, geração de imagens, ensaio fotográfico, inteligência artificial',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="pt-BR">
      <body className={`${playfair.variable} ${dmSans.variable} ${dmMono.variable}`}>
        {children}
      </body>
    </html>
  )
}
