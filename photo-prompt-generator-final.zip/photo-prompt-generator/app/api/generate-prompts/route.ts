import { NextRequest, NextResponse } from 'next/server'
import Anthropic from '@anthropic-ai/sdk'

const client = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY,
})

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData()
    const imageFile = formData.get('image') as File

    if (!imageFile) {
      return NextResponse.json({ error: 'Nenhuma imagem fornecida.' }, { status: 400 })
    }

    const bytes = await imageFile.arrayBuffer()
    const buffer = Buffer.from(bytes)
    const base64Image = buffer.toString('base64')

    const mediaType = imageFile.type as 'image/jpeg' | 'image/png' | 'image/webp' | 'image/gif'

    const systemPrompt = `Você é um especialista em fotografia e geração de prompts para IA de imagens hiper-realistas. 
Sua tarefa é analisar fotos de referência e criar prompts detalhados em português que capturam todos os elementos visuais e técnicos da imagem.

Ao analisar uma imagem, extraia e descreva:
- Cenário e ambiente (interior/exterior, locação, decoração, fundo)
- Iluminação (tipo, direção, temperatura de cor, intensidade, sombras)
- Pose e posição do corpo (postura, ângulo, expressão facial, gestos)
- Enquadramento e composição (plano, regra dos terços, ponto focal)
- Estilo fotográfico (editorial, fashion, retrato, comercial, artístico)
- Equipamento simulado (lente, abertura, distância focal)
- Emoção e atmosfera (mood, sentimento transmitido)
- Profundidade de campo (bokeh, nitidez, planos)
- Vestuário, cabelo, maquiagem e acessórios
- Paleta de cores dominante

Gere EXATAMENTE 5 prompts no formato JSON especificado. Cada prompt deve ser extremamente detalhado (mínimo 80 palavras cada), técnico e pronto para uso em geradores de imagem como Midjourney, DALL-E 3 ou Stable Diffusion.

Responda APENAS com JSON válido, sem texto adicional, sem markdown, sem explicações.`

    const userPrompt = `Analise esta imagem de referência fotográfica e gere exatamente 5 prompts detalhados em português.

Retorne APENAS este JSON (sem markdown, sem explicações):

{
  "prompts": [
    {
      "id": 1,
      "titulo": "Fiel ao Original",
      "descricao": "Descrição extremamente fiel à foto original, quase idêntica",
      "prompt": "[prompt detalhado aqui]"
    },
    {
      "id": 2,
      "titulo": "Variação de Ângulo",
      "descricao": "A mesma cena com uma pequena variação de ângulo de câmera",
      "prompt": "[prompt detalhado aqui]"
    },
    {
      "id": 3,
      "titulo": "Variação de Pose",
      "descricao": "A mesma cena com variação de pose do modelo",
      "prompt": "[prompt detalhado aqui]"
    },
    {
      "id": 4,
      "titulo": "Variação de Iluminação",
      "descricao": "A mesma cena com pequena variação de iluminação ou enquadramento",
      "prompt": "[prompt detalhado aqui]"
    },
    {
      "id": 5,
      "titulo": "Variação Criativa",
      "descricao": "Uma variação criativa como outro clique do mesmo ensaio",
      "prompt": "[prompt detalhado aqui]"
    }
  ]
}`

    const response = await client.messages.create({
      model: 'claude-opus-4-5',
      max_tokens: 4000,
      system: systemPrompt,
      messages: [
        {
          role: 'user',
          content: [
            {
              type: 'image',
              source: {
                type: 'base64',
                media_type: mediaType,
                data: base64Image,
              },
            },
            {
              type: 'text',
              text: userPrompt,
            },
          ],
        },
      ],
    })

    const content = response.content[0]
    if (content.type !== 'text') {
      throw new Error('Resposta inesperada da API')
    }

    let jsonText = content.text.trim()
    // Strip markdown code blocks if present
    jsonText = jsonText.replace(/^```json\s*/i, '').replace(/^```\s*/i, '').replace(/\s*```$/i, '')

    const parsed = JSON.parse(jsonText)
    return NextResponse.json(parsed)
  } catch (error) {
    console.error('Erro ao gerar prompts:', error)

    if (error instanceof SyntaxError) {
      return NextResponse.json(
        { error: 'Erro ao processar resposta da IA. Tente novamente.' },
        { status: 500 }
      )
    }

    if (error instanceof Error && error.message.includes('API')) {
      return NextResponse.json(
        { error: 'Erro na API. Verifique sua chave ANTHROPIC_API_KEY.' },
        { status: 500 }
      )
    }

    return NextResponse.json(
      { error: 'Erro interno ao processar a imagem. Tente novamente.' },
      { status: 500 }
    )
  }
}
